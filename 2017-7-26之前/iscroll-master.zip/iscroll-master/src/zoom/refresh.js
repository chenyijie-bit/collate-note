
	this.scrollerWidth	= Math.round(rect.width * this.scale);
	this.scrollerHeight	= Math.round(rect.height * this.scale);

	this.maxScrollX		= this.wrapperWidth - this.scrollerWidth;
	this.maxScrollY		= this.wrapperHeight - this.scrollerHeight;
